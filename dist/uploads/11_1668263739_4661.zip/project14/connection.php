<?php
$conn = new mysqli("localhost",'root','','polyphpmysql') or die("Cannot connect to database");
$conn->set_charset('utf8');