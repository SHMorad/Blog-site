<?php
session_start();
require "dist/inc/auth.php";
require 'connection.php';
    if (isset($_POST['submit'])) {
        // $error = false;
        $command = $_POST['userCom'];
        $image = $_FILES['image'];
        $imgName = $image['name'];
        $imgTmpName = $image['tmp_name'];
        $imgSize = $image['size'];
        $error = $image['error'];

        if ($error === 0) {
            if ($imgSize > 524000) {
                $em = "Sorry, your file is to large...";
                echo $em;
                // header("location: dashboard.php?error=$em");
            }
            else{
                $img_ex = pathinfo($imgName,PATHINFO_EXTENSION);
                $img_ex_lc = strtolower($img_ex);

                $allowed_exs = array("jpg","jpeg","png");
                if (in_array($img_ex_lc,$allowed_exs)) {
                    $new_img_name = uniqid("MIG-",true).'.'.$img_ex_lc;
                    $path =  "dist/Uploads/".$new_img_name;
                    $upload =  move_uploaded_file($imgTmpName,$path);
                    $sql = "insert into article values (nul,'$command','$new_img_name',null)";
                    // echo $sql;
                    $conn->query($sql);
                    // mysqli_query($conn,$sql);
                }
            }
        }
    }




    //html head 
    require 'dist/inc/head.php';
?>

<body>
    <?php
        require 'dist/inc/header.php';
        require 'dist/inc/navbar.php';
    ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
            </div>
            <div class="col-md-4">
                <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit.</p>
            </div>
        </div>
        <div class="row">
            <div class="col-md-8">
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
            </div>
            <div class="col-md-4">
                <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit.</p>
            </div>
        </div>
    </div>
    <?php require 'dist/inc/footer.php' ?>
    <?php
        $sql =  "SELECT * FROM article ORDER BY id DESC";
        $res = mysqli_query($conn,  $sql);
        if (mysqli_num_rows($res)>0) {
            while ($images = mysqli_fetch_assoc($res)) {?>
                <div class="alb">
                    <img src="dist/Uploads/<?=$image['image']?>" alt="this image not found..">
                </div>
    <?php   }
        }
    
    ?>


    <?php
        require 'dist/inc/bootstrapjscdn.php';
    ?>
    <script>
        function imageTrigger(){
            document.getElementById('image').click();
        }
        function displayImage(e){
            // console.log(e.files[0]);
            var reader = new FileReader;
            reader.onload = function(event){
                document.getElementById('imagePlaceholder').setAttribute('src',event.target.result);
            }
            reader.readAsDataURL(e.files[0]);
        }
    </script>
</body>

</html>