<?php
session_start();
require "dist/inc/adminauth.php";
require "connection.php";
//search start
if(isset($_GET['q'])){
    $search = $conn->escape_string($_GET['q']);
    $whereSql = "username like'%".$search."%' or username like'%".$search."%'";
    $searchstr =$search;
}
//search end

$count = 5;
$page = isset($_GET['page'])?$_GET['page']:1;
$index =($page-1)*$count;
if(isset($whereSql)) {
    $totalRecords = "select count(*) as total from users where ".$whereSql;
}else {
    $totalRecords = "select count(*) as total from users";
}
$ttr = $conn->query($totalRecords);
$row = $ttr->fetch_assoc();
$totalRec = $row['total'];
$totalPage = ceil($totalRec/$count);
// echo $totalPage;
if (isset($whereSql)) {
    $userQ = "select * from users where ".$whereSql." limit $index,$count";
} else {
    $userQ = "select * from users where 1 limit $index,$count";
}

$userRecords = $conn->query($userQ);
// echo $userRecords->num_rows;

//html head..
require 'dist/inc/head.php';
?>


<body>
    <?php
        require 'dist/inc/header.php';
        require 'dist/inc/navbar.php';
    ?>
    <div class="container">
        <section>
            <div class="float-start">
                <h3>Users List</h3>
                <button class="btn btn-success">
                    <a href="useradd.php" class="text-white"><i class="fa-solid fa-plus"></i></a>
                </button>
            </div>
            <div class="float-end">
                <form method="get">
                    <div class="float-start">
                        <input type="search" name="search" class="form-control" id="searchInput" placeholder="search information">
                    </div>
                    <input type="button" class="btn btn-success" id="searchBtn" value="Search">
                    <?php 
                        // if (isset($searchstr)) {
                    ?>
                        <!-- <input type="button" value="&times" id="clearSearchBtn"> -->
                    <?php
                        // }
                    ?>
                </form>

                <!-- <form action="" style="margin-right:10px">                    
                    <input type="search" name="search" id="search" placeholder="username or email search" title="search usrename or email and click the search button">
                    <input type="button" value="Search" id="searchbtn">
                    <?php
                    // if(isset($searchstr)){
                        ?>
                    <input type="button" value="&times;" id="clearsearchbtn">
                    <?php
                    // }
                    ?>
                </form> -->
            </div>
            <table class="table table-bordered table-hover">
                <caption><?php echo isset($_GET['message'])?$_GET['message']:""; ?></caption>
                <tr>
                    <th>ID</th>
                    <th>User Name</th>
                    <th>Email</th>
                    <th>Status</th>
                    <th>Registration Time</th>
                    <th>Action</th>
                </tr>
            
                <?php
                if($userRecords->num_rows){
                    $record = "";
                    while($row = $userRecords->fetch_assoc()){
                    $record .= "<tr>";
                    $record .= "<td>{$row['id']}</td>";
                    $record .= "<td>{$row['username']}</td>";
                    $record .= "<td>{$row['email']}</td>";
                    $record .= "<td>{$row['status']}</td>";
                    $record .= "<td>{$row['created_at']}</td>";
                    $record .= "<td>
                        <button class='btn btn-success'>
                            <a href='useredit.php?id={$row['id']}'class='text-white'><i class='fa-solid fa-pen-to-square'></i></a>
                        </button>
                        ||
                        <button class='btn btn-danger'>
                            <a href='userdelete.php?id={$row['id']}'class='text-white' onclick=\"return confirm('Are you sure?')\"><i class='fa-solid fa-trash '></i></a>
                        </button>
                    </td>";
                    // $record .= "<td><a href='useredit.php?id={$row['id']}'><i class='fa-solid fa-pen-to-square'></i></a> | <a href='userdelete.php?id={$row['id']}' onclick=\"return confirm('Are you sure?')\"><i class='fa-solid fa-trash'></i></a></td>";
                    $record .= "</tr>";
                    }
                    echo $record;
                }
                ?>
            </table>
            <?php
                if(isset($searchstr)){
                    $str = "&q=" . $searchstr;
                }
                else{
                    $str = null;
                }
            ?>
            <nav aria-label="..." class="float-end">
                <ul class="pagination">
                    <li class="page-item <?php echo ($page=="1")?"disabled":""; ?>">
                        <a class="page-link" href="?page=<?php echo ($page-1).$str; ?>"> Previous </a>
                    </li>
                        <?php
                        for ($i=1; $i<= $totalPage ; $i++) {
                            if(abs($i - $page) < 5){
                        ?>
                            <li class="page-item <?php echo ($page==$i)?"active":""; ?> "aria-current="page">
                                <a class="page-link" href="?page=<?php echo $i.$str ?>"><?php echo $i ?></a>
                            </li>
                        <?php
                            }
                        }
                        ?>
                    <li class="page-item <?php echo ($page==$totalPage)?"disabled":""; ?>">
                        <a class="page-link" href="?page=<?php echo ($page+1).$str;?>"> Next </a>
                    </li>
                </ul>
            </nav>
        </section>
                
    </div>
    <script src="dist/js/jquery-3.6.1.min.js"></script>
    <script>
        $(document).ready(function(){
            // alert(5)
            $("#searchBtn").click(function(){
                $searchVal = $("#searchInput").val();
                // console.log($searchVal);
                window.location = "user.php?q=" + $searchVal;
            })
            // $("#clearSearchBtn").click(function(){
            //     window.location = "user.php";
            // })
        })
        // $(document).ready(function(){
        //     // alert(5)
        //     $("#searchbtn").click(function(){
        //         $searchval = $("#search").val();
        //         window.location = "user.php?q=" + $searchval;
        //     });
        //     $("#clearsearchbtn").click(function(){
                
        //         window.location = "user.php";
        //     });
        // });
    </script>
    <?php 
    require 'dist/inc/bootstrapjscdn.php';
    require 'dist/inc/footer.php';
    ?>
</body>
</html>